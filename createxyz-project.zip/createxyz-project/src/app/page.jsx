"use client";
import React from "react";

function MainComponent() {
  return (
    <div className="w-screen h-screen">
      <iframe
        src="https://superprofile.bio/vp/667d053551a2fd00137db2a2"
        className="w-full h-full border-0"
        title="Superprofile Bio"
      />
    </div>
  );
}

export default MainComponent;